package com.example.booodima.My_Data_Classes

data class Room(
    val roomId: Int,
    val roomType: String,
    val address: String,
    val price: String,
    val beds: Int
)

